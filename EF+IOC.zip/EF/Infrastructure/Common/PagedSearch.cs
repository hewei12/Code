﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Common
{
    public class PagedSearch
    {
        /// <summary>
        /// 
        /// </summary>
        public int PageSize { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Page { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public PagedSearch()
        {}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="page"></param>
        public PagedSearch(int pageSize,int page):this()
        {
            this.Page = page;
            this.PageSize = PageSize;
        }
    }

    public class PagedSearch<T>:PagedSearch
    {
        public T Condition { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="page"></param>
        public PagedSearch(int pageSize,int page):base(pageSize,page)
        {}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="page"></param>
        /// <param name="condition"></param>
        public PagedSearch(int pageSize,int page,T condition)
        {
            Condition = condition;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="condition"></param>
        public PagedSearch(T condition)
        {
            Condition = condition;
        }
    }
}
