﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Infrastructure.Cache
{
    public class CacheProvider : ICacheProvider
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add<T>(string key, T value)
        {
            if (!HttpContext.Current.Items.Contains(key))
            {
                HttpContext.Current.Items.Add(key, value);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public T CreateOrGet<T>(string key, Func<string, T> m)
        {
            //key = GenerateKeyValue(key);
            T value;
            if (TryGet(key, out value))
            {
                return value;
            }
            else
            {
                value = m(key);
                Add<T>(key, value);
                return value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public T CreateOrGet<T>(string key, Func<T> m)
        {
            //key = GenerateKeyValue(key);
            T value;
            if (TryGet(key, out value))
            {
                return value;
            }
            else
            {
                value = m();
                Add<T>(key, value);
                return value;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GenerateKeyValue(string key)
        {
            return string.Concat("xxxxxxxxxxxx_", key);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value">out参数 内赋值</param>
        /// <returns></returns>
        public bool TryGet<T>(string key, out T value)
        {
            bool isExist = false;
            key = GenerateKeyValue(key);
            if (HttpContext.Current.Items.Contains(key))
            {
                isExist = true;
                object entity = HttpContext.Current.Items[key];
                if (entity != null && !(entity is T))
                {
                    throw new System.Exception("xxxxxxxxxxxxxxxxxxxxxxxx");
                }
                value = (T)entity;
            }
            else
                value = default(T);
            return isExist;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="key"></param>
        public void Delete(string key)
        {
            key = GenerateKeyValue(key);
            HttpContext.Current.Items.Remove(key);
        }
    }
}
