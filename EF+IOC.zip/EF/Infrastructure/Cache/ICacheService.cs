﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Cache
{
    public interface ICacheService
    {
        object Get(string key);

        List<string> GetCacheKeys();

        void Set(string key, object cacheObj, TimeSpan expiration);

        void Delete(string key);

        bool Exist(string key);

        void Flush();
    }
}
