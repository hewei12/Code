﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Caching;

namespace Infrastructure.Cache
{
    public class CacheService : ICacheService
    {
        private System.Web.Caching.Cache cache;

        public CacheService()
        {
            cache = HttpRuntime.Cache;
        }

        public void Delete(string key)
        {
            if (Exist(key))
                cache.Remove(key);
        }

        public bool Exist(string key)
        {
            if (cache[key] != null)
            {
                return true;
            }
            return false;
        }

        public void Flush()
        {
            foreach (string key in GetCacheKeys())
            {
                Delete(key);
            }
        }

        public object Get(string key)
        {
            return cache.Get(key);
        }

        public List<string> GetCacheKeys()
        {
            List<string> keys = new List<string>();
            IDictionaryEnumerator ca = cache.GetEnumerator();
            while (ca.MoveNext())
                keys.Add(ca.Key.ToString());
            return keys;
        }

        public void Set(string key, object cacheObj, TimeSpan expiration)
        {
            cache.Insert(key, cacheObj, null, System.Web.Caching.Cache.NoAbsoluteExpiration, 
                expiration, CacheItemPriority.Normal, null);
        }
    }
}
