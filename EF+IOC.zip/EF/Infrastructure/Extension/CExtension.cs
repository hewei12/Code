﻿using Bing.Utils.Extensions;
using Infrastructure.Extension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Extension
{
    public static class CExtension
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNullOrEmpty(this string value)
        {
            return string.IsNullOrEmpty(value);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNullOrWriteSpace(this string value)
        {
            return string.IsNullOrWhiteSpace(value);
        }

        #region
        //public static bool IsEmpty(this Guid value)
        //{
        //    if (value == Guid.Empty)
        //    {
        //        return true;
        //    }
        //    return false;
        //}
        #endregion
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsEmpty(this Guid? value)
        {
            if (value == null || value == Guid.Empty)
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNull(this object value)
        {
            return value.IsNull<object>();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNull<T>(this T value)
        {
            var result = ReferenceEquals(value, null);
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="aa"></param>
        /// <returns></returns>
        public static T SafeValue<T>(this T? aa) where T : struct
        {
            return aa ?? default(T);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="aa"></param>
        /// <returns></returns>
        public static string SafeString(this string aa)
        {
            return aa ?? string.Empty;
        }
    }
}
