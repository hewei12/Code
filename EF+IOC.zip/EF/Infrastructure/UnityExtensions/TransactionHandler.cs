﻿using Infrastructure.Common;
using Microsoft.Practices.Unity.InterceptionExtension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Infrastructure.UnityExtensions
{
    /// <summary>
    /// 
    /// </summary>
    public class TransactionHandler : ICallHandler
    {
        public static bool enableTransction = ConfigUtils.GetAppSettings("EnableTranction") == "0" ? false : true;
        public int Order { get; set; }
        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            if (!enableTransction)
            {
                IMethodReturn methodReturn = getNext()(input, getNext);
                if (methodReturn.Exception != null)
                {
                    input.CreateExceptionMethodReturn(methodReturn.Exception);
                }
                return methodReturn;
            }
            TransactionOptions transactionOption = new TransactionOptions();
            transactionOption.IsolationLevel = IsolationLevel.ReadCommitted;
            using (TransactionScope transactionScope=new TransactionScope(TransactionScopeOption.Required,transactionOption))
            {
                IMethodReturn methodReturn = getNext()(input, getNext);
                if(methodReturn.Exception!=null)
                {
                    return input.CreateExceptionMethodReturn(methodReturn.Exception);
                }
                transactionScope.Complete();
                return methodReturn;
            }
        }
    }
}
