﻿using log4net;
using Microsoft.Practices.Unity.InterceptionExtension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Logs.Log4Net;
using Wolf.Infrastructure.Logs;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace Infrastructure.UnityExtensions
{
    public class ExceptionLogBehavior : IInterceptionBehavior
    {
        private static readonly Wolf.Infrastructure.Logs.ILog Logger = Log.GetLog(typeof(ExceptionLogBehavior));
        /// <summary>
        /// 获取一个值，该值表示当前拦截行为被调用时，是否真的需要执行
        /// </summary>
        public bool WillExecute
        {
            get
            {
                return true;
            }
        }

        public IEnumerable<Type> GetRequiredInterfaces()
        {
            return Type.EmptyTypes;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="getNext"></param>
        /// <returns></returns>
        public IMethodReturn Invoke(IMethodInvocation input, GetNextInterceptionBehaviorDelegate getNext)
        {
            IMethodReturn retvalue = getNext()(input, getNext);
            if (retvalue.Exception == null)
            {
                //Console.WriteLine("执行成功，无异常");
            }
            else
            {
                Logger.Caption("日志拦截器-异常");
                if (input.MethodBase.DeclaringType != null)
                {
                    Logger.Class(input.MethodBase.DeclaringType.FullName);
                }
                Logger.Method(input.MethodBase.Name);
                Logger.Params("参数: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(input.Arguments));
                Logger.Exception(retvalue.Exception);
                Logger.Error();
                retvalue.Exception = null;
            }
            return retvalue;
        }
    }
}
