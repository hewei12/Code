﻿using Microsoft.Practices.Unity.InterceptionExtension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;

namespace Infrastructure.UnityExtensions
{
    [AttributeUsage(AttributeTargets.Method)]
    public class CachingCallHandlerAttribute:HandlerAttribute
    {
        public readonly TimeSpan? ExpirationTime;
        public CachingCallHandlerAttribute(string expireTime="")
        {
            if(!string.IsNullOrEmpty(expireTime))
            {
                TimeSpan expireTimeSpan;
                if(!TimeSpan.TryParse(expireTime,out expireTimeSpan))
                {
                    throw new ArgumentException("输入的时间格式不正确");
                }
                this.ExpirationTime = expireTimeSpan;
            }
        }

        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            return container.Resolve<CachingCallHandler>();
        }
    }
}
