﻿using Infrastructure.Cache;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.InterceptionExtension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.UnityExtensions
{
    /// <summary>
    /// 
    /// </summary>
    public class CachingCallHandler:ICallHandler
    {
        [Dependency]
        public ICacheService Cache { get; set; }

        public readonly TimeSpan ExpirationTime;
        internal readonly static TimeSpan DefaultExpirationTime;
        internal readonly static Func<MethodBase, object[], string> CacheKeyGenerator;

        static CachingCallHandler()
        {
            DefaultExpirationTime = new TimeSpan(0, 0, 60);
            Guid prefix = Guid.NewGuid();
            CacheKeyGenerator = (method, inputs) =>
              {
                  StringBuilder sb = new StringBuilder();
                  sb.AppendFormat("{0}:", prefix);
                  sb.AppendFormat("{0}:", method.DeclaringType.FullName);
                  sb.AppendFormat("{0}:", method.Name);
                  if (null != inputs)
                  {
                      Array.ForEach(inputs, input =>
                     {
                         string hashCode = (null == input) ? "" : input.GetHashCode().ToString();
                         sb.AppendFormat("{0}:", hashCode);
                     });
  
                  }
                  return sb.ToString().TrimEnd(':');
              };
        }

        public CachingCallHandler()
        {
            this.ExpirationTime = DefaultExpirationTime;
        }

        public IMethodReturn Invoke(IMethodInvocation input,GetNextHandlerDelegate getNext)
        {
            MethodInfo targetMethod = (MethodInfo)input.MethodBase;
            if(targetMethod.ReturnType==typeof(void))
            {
                return getNext()(input,getNext);
            }
            object[] inputs = new object[input.Inputs.Count];
            input.Inputs.CopyTo(inputs, 0);
            string cacheKey = CacheKeyGenerator(targetMethod, inputs);
            object cacheResult = Cache.Get(cacheKey);
            if(null==cacheResult)
            {
                IMethodReturn realReturn = getNext()(input,getNext);
                if (null == realReturn.Exception)
                    Cache.Set(cacheKey, realReturn.ReturnValue, this.ExpirationTime);
                return realReturn;
            }
            return input.CreateMethodReturn(cacheResult,input.Arguments);
        }

        public int Order { get; set; }
    }
}
