﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Enum
{
    public enum ExportFileType
    {
        /// <summary>
        /// 商品
        /// </summary>
        [Description("商品")]
        Goods = 1,
        /// <summary>
        /// 套装商品
        /// </summary>
        [Description("套装商品")]
        GoodsPackages = 2,
        /// <summary>
        /// 组合商品
        /// </summary>
        [Description("组合商品")]
        GoodsSet = 3,
        /// <summary>
        /// 色号
        /// </summary>
        [Description("色号")]
        Color = 4,
        /// <summary>
        /// 供应商
        /// </summary>
        [Description("供应商")]
        Vender = 5,
        /// <summary>
        /// 国标码
        /// </summary>
        [Description("国标码")]
        Barcode = 6,
        /// <summary>
        /// 商品分类
        /// </summary>
        [Description("商品分类")]
        GoodsDept = 7,
        /// <summary>
        /// 服务
        /// </summary>
        [Description("服务")]
        Services = 8,
        /// <summary>
        /// 服务套餐
        /// </summary>
        [Description("服务套餐")]
        ServicePackages = 9,
        /// <summary>
        /// 加盟商
        /// </summary>
        [Description("加盟商")]
        Franchisee = 10,
        /// <summary>
        /// 加盟商商品等级价
        /// </summary>
        [Description("加盟商商品等级价")]
        FranchiseeGoodsGradesPrice = 11,
        /// <summary>
        /// 店铺
        /// </summary>
        [Description("店铺")]
        Shop = 12,
        /// <summary>
        /// 转让记录
        /// </summary>
        [Description("转让记录")]
        TransferRecords = 13,
        /// <summary>
        /// 店员
        /// </summary>
        [Description("店员")]
        ShopClerk = 14,
        /// <summary>
        /// 会员
        /// </summary>
        [Description("会员")]
        Member = 15,
        /// <summary>
        /// 上架商品
        /// </summary>
        [Description("上架商品")]
        OnlineGoods = 16,
        /// <summary>
        /// 上架套装商品
        /// </summary>
        [Description("上架套装商品")]
        OnlineGoodsPackages = 17,
        /// <summary>
        /// 上架服务
        /// </summary>
        [Description("上架服务")]
        OnlineServices = 18,
        /// <summary>
        /// 上架店铺
        /// </summary>
        [Description("上架店铺")]
        OnlineShop = 19
    }
}
