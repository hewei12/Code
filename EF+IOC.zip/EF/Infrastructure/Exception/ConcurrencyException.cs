﻿using Bing.Utils.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Logs;

namespace Infrastructure.Exception
{
    public class ConcurrencyException:Warning
    {
        /// <summary>
        /// 初始化并发异常
        /// </summary>
        /// <param name="exception">异常</param>
        public ConcurrencyException(System.Exception exception)
            : this("", exception)
        {
        }

        /// <summary>
        /// 初始化并发异常
        /// </summary>
        /// <param name="message">错误消息</param>
        /// <param name="exception">异常</param>
        public ConcurrencyException(string message, System.Exception exception)
            : this(message, exception, "")
        {
        }

        /// <summary>
        /// 初始化并发异常
        /// </summary>
        /// <param name="message">错误消息</param>
        /// <param name="exception">异常</param>
        /// <param name="code">错误码</param>
        public ConcurrencyException(string message, System.Exception exception, string code)
            : this(message, exception, code, LogLevel.Error)
        {
        }

        /// <summary>
        /// 初始化并发异常
        /// </summary>
        /// <param name="message">错误消息</param>
        /// <param name="exception">异常</param>
        /// <param name="code">错误码</param>
        /// <param name="level">日志级别</param>
        public ConcurrencyException(string message, System.Exception exception, string code, LogLevel level)
            : base(message)
        {
        }
    }
}
