﻿
using Domain.AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace Domain.AutoMapper
{
    public static class MapperExtension
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDesity"></typeparam>
        /// <param name="entities"></param>
        /// <returns></returns>
        public static IList<TDesity> MapToList<TSource, TDesity>(this List<TSource> entities) where TDesity : class where TSource : class
        {
            List<TDesity> list = new List<TDesity>();
            
            foreach (var item in entities)
            {
                var tDesity = Mapper.Map<TDesity>(item);
                list.Add(tDesity);
            }
            return list;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDesity"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static TDesity MapTo<TSource, TDesity>(this TSource entity) where TDesity : class where TSource : class
        {
            return Mapper.Map<TDesity>(entity);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static TDesity MapTo<TDesity>(this object entity)
        {
            return Mapper.Map<TDesity>(entity);
        }
    }
}
