﻿
using AutoMapper;
using EFModel;
//using Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.AutoMapper
{
    public class MapperProfile : Profile
    {
        //TODO
        protected override void Configure()
        {
            #region 一次性
            //Mapper.Initialize(x => x.CreateMap<Domain.Model.Dept, Dept>());
            //Mapper.Initialize(x => x.CreateMap<Dept, Domain.Model.Dept>());
            #endregion

            #region 多次性
            Mapper.CreateMap<Domain.Model.Dept, Dept>();
            Mapper.CreateMap<Dept, Domain.Model.Dept>();
            #endregion
        }
    }
}
