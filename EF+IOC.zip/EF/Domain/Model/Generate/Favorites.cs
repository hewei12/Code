//----------Favorites开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Favorites 
    /// </summary>        
    public partial class Favorites
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid FavoritesID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int FavoritesType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid FavoritesData {get;set;}   
        
        #endregion
    }    
}
//----------Favorites结束----------
    