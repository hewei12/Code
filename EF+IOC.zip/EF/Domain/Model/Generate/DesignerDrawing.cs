//----------DesignerDrawing开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// DesignerDrawing 
    /// </summary>        
    public partial class DesignerDrawing
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid DesignerDrawingID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public int DecorationType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? Designer {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Description {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int FavoritiesCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int ReadCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? PictureCount {get;set;}   
        
        #endregion
    }    
}
//----------DesignerDrawing结束----------
    