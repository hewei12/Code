//----------Region开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Region 
    /// </summary>        
    public partial class Region
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid RegionID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string EName {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Code {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? ParentID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int LevelID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------Region结束----------
    