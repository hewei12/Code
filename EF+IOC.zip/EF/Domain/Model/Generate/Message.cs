//----------Message开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Message 
    /// </summary>        
    public partial class Message
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MessageID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Content {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int MessageType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int ReadFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------Message结束----------
    