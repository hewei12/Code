//----------Cart开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Cart 
    /// </summary>        
    public partial class Cart
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid CartID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? BarCodeID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Qty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        #endregion
    }    
}
//----------Cart结束----------
    