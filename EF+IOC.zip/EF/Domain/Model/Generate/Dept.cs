//----------Dept开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Dept 
    /// </summary>        
    public partial class Dept
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid DeptID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Code {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string LongName {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? ParentID {get;set;}   
        
        #endregion
    }    
}
//----------Dept结束----------
    