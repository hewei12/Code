//----------BasStatisticsData开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// BasStatisticsData 
    /// </summary>        
    public partial class BasStatisticsData
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid BasStatisticsDataID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime StatisticsDate {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? LoginCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? RegisterCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? OrderCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? OrderAmount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------BasStatisticsData结束----------
    