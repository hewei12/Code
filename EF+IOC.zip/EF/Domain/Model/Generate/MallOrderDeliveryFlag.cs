//----------MallOrderDeliveryFlag开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// MallOrderDeliveryFlag 
    /// </summary>        
    public partial class MallOrderDeliveryFlag
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MallOrderDeliveryFlagID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid MallOrderID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int DeliveryFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------MallOrderDeliveryFlag结束----------
    