//----------TimeDiscount开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// TimeDiscount 
    /// </summary>        
    public partial class TimeDiscount
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid TimeDiscountID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int DiscountType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal DiscountData {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int DiscountCondition {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int GoodsFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int OpenQty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime BeginTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EndTime {get;set;}   
        
        #endregion
    }    
}
//----------TimeDiscount结束----------
    