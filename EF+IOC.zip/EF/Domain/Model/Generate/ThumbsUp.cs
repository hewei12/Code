//----------ThumbsUp开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// ThumbsUp 
    /// </summary>        
    public partial class ThumbsUp
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid ThumbsUpID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int ThumbsUpType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid ThumbsUpData {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------ThumbsUp结束----------
    