//----------LoginMenus开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// LoginMenus 
    /// </summary>        
    public partial class LoginMenus
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid LoginMenusID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? LoginID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? MenusID {get;set;}   
        
        #endregion
    }    
}
//----------LoginMenus结束----------
    