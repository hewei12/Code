//----------BarCode开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// BarCode 
    /// </summary>        
    public partial class BarCode
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid BarCodeID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid GoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid SizeID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid ColorID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string CustomBC {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int StockQty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? MarketPrice {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? SalePrice {get;set;}   
        
        #endregion
    }    
}
//----------BarCode结束----------
    