//----------DecorationQuotation开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// DecorationQuotation 
    /// </summary>        
    public partial class DecorationQuotation
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid DecorationQuotationID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal Area {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? State {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? City {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? District {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? RoomCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int HallCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? ToiletCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Mobile {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Flag {get;set;}   
        
        #endregion
    }    
}
//----------DecorationQuotation结束----------
    