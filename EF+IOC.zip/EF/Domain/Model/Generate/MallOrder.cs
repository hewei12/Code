//----------MallOrder开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// MallOrder 
    /// </summary>        
    public partial class MallOrder
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MallOrderID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? BarCodeID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Sheet {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? State {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? City {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? District {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Address {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string LinkMan {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Phone {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Mobile {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? ItemAmount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? InstallFee {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? Discount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? TotalAmount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? TotalQty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string BuyerMemo {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int DeliveryFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int RefundFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Flag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? PayTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? SendTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? ConfirmTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid DiscountID {get;set;}   
        
        #endregion
    }    
}
//----------MallOrder结束----------
    