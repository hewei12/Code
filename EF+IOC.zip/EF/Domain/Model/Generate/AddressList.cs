//----------AddressList开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// AddressList 
    /// </summary>        
    public partial class AddressList
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid AddressListID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string LinkMan {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Address {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Mobile {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string ZipCode {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int DefaultFlag {get;set;}   
        
        #endregion
    }    
}
//----------AddressList结束----------
    