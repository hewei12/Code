//----------FullReduceGoods开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// FullReduceGoods 
    /// </summary>        
    public partial class FullReduceGoods
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid FullReduceGoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid FullReduceID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid GoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int SalesQty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Flag {get;set;}   
        
        #endregion
    }    
}
//----------FullReduceGoods结束----------
    