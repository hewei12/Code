//----------MerchantsEnter开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// MerchantsEnter 
    /// </summary>        
    public partial class MerchantsEnter
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MerchantsEnterID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Brand {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Company {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? State {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? City {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? District {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Mobile {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int MerchantsType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------MerchantsEnter结束----------
    