//----------UserOAuthMapping开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// UserOAuthMapping 
    /// </summary>        
    public partial class UserOAuthMapping
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public string AppID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int AuthType {get;set;}   
        
        #endregion
    }    
}
//----------UserOAuthMapping结束----------
    