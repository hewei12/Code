//----------MallOrderItem开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// MallOrderItem 
    /// </summary>        
    public partial class MallOrderItem
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MallOrderItemID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? MallOrderID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? Qty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? Price {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? InstallFee {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? DiscountType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string DiscountContent {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? RefundFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------MallOrderItem结束----------
    