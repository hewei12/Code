//----------FullReduce开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// FullReduce 
    /// </summary>        
    public partial class FullReduce
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid FullReduceID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal ReduceType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal ReduceMoney {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int FreeDeliveryFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int GoodsFlag {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime BeginTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EndTime {get;set;}   
        
        #endregion
    }    
}
//----------FullReduce结束----------
    