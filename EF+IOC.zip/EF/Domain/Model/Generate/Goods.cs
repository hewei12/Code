//----------Goods开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Goods 
    /// </summary>        
    public partial class Goods
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid GoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid DeptID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid MerchantsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string CustomNo {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Title {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Brand {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int SaleQty {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? BasePrice {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? MarketPrice {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? SalePrice {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? InstallFee {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Unit {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int StockStatus {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? SendTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int? Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime? EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------Goods结束----------
    