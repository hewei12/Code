//----------Article开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Article 
    /// </summary>        
    public partial class Article
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid ArticleID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int ClickCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int FavoritesCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int CommentCount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int ArticleType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Description {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Content {get;set;}   
        
        #endregion
    }    
}
//----------Article结束----------
    