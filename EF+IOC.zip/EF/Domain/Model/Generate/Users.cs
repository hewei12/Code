//----------Users开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// Users 
    /// </summary>        
    public partial class Users
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid UserID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Name {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Login {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string PassWord {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? State {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? City {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid? District {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Address {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int LoginType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string WeChat {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string QQ {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Token {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Mobile {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal? Amount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Status {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        #endregion
    }    
}
//----------Users结束----------
    