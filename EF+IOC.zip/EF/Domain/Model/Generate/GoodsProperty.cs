//----------GoodsProperty开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// GoodsProperty 
    /// </summary>        
    public partial class GoodsProperty
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid GoodsPropertyID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid GoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid PropertyID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Data {get;set;}   
        
        #endregion
    }    
}
//----------GoodsProperty结束----------
    