//----------GoodsInfo开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// GoodsInfo 
    /// </summary>        
    public partial class GoodsInfo
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid GoodsInfoID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid GoodsID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int InfoType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Content {get;set;}   
        
        #endregion
    }    
}
//----------GoodsInfo结束----------
    