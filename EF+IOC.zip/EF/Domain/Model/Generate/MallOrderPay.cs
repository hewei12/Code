//----------MallOrderPay开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// MallOrderPay 
    /// </summary>        
    public partial class MallOrderPay
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Creater {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime CreateTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Editor {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public DateTime EditTime {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Note {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid MallOrderPayID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid MallOrderID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string Sheet {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int PayType {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public decimal Amount {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public string PayID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public int Flag {get;set;}   
        
        #endregion
    }    
}
//----------MallOrderPay结束----------
    