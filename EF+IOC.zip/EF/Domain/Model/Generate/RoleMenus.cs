//----------RoleMenus开始----------    
using System;
using Wolf.Infrastructure.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
   
namespace Domain.Model
{
    /// <summary>
    /// RoleMenus 
    /// </summary>        
    public partial class RoleMenus
    {            
        #region Property(属性)
        
        /// <summary>
        /// 
        /// </summary>
		        [Key]
        public Guid RoleMenusID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid RoleID {get;set;}   
        
        /// <summary>
        /// 
        /// </summary>
		        
        public Guid MenusID {get;set;}   
        
        #endregion
    }    
}
//----------RoleMenus结束----------
    