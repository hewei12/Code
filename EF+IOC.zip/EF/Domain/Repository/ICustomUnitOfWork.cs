﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Domain.Uow;

namespace Domain.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICustomUnitOfWork:IUnitOfWork
    {
    }
}
