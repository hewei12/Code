
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// LoginMenus 仓储
    /// </summary>        
    public partial interface ILoginMenusRepository:IRepository<LoginMenus>
    {
       
    }    
}

    