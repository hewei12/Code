
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// ThumbsUp 仓储
    /// </summary>        
    public partial interface IThumbsUpRepository:IRepository<ThumbsUp>
    {
       
    }    
}

    