
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Dept 仓储
    /// </summary>        
    public partial interface IDeptRepository:IRepository<Dept>
    {
       
    }    
}

    