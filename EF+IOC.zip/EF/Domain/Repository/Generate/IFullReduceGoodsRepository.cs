
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// FullReduceGoods 仓储
    /// </summary>        
    public partial interface IFullReduceGoodsRepository:IRepository<FullReduceGoods>
    {
       
    }    
}

    