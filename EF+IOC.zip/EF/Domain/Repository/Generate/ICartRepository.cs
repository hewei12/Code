
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Cart 仓储
    /// </summary>        
    public partial interface ICartRepository:IRepository<Cart>
    {
       
    }    
}

    