
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// BasStatisticsData 仓储
    /// </summary>        
    public partial interface IBasStatisticsDataRepository:IRepository<BasStatisticsData>
    {
       
    }    
}

    