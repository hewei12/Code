
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Merchants 仓储
    /// </summary>        
    public partial interface IMerchantsRepository:IRepository<Merchants>
    {
       
    }    
}

    