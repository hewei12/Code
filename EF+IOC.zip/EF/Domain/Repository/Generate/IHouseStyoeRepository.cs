
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// HouseStyoe 仓储
    /// </summary>        
    public partial interface IHouseStyoeRepository:IRepository<HouseStyoe>
    {
       
    }    
}

    