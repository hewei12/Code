
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// TimeDiscountGoods 仓储
    /// </summary>        
    public partial interface ITimeDiscountGoodsRepository:IRepository<TimeDiscountGoods>
    {
       
    }    
}

    