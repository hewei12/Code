
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Favorites 仓储
    /// </summary>        
    public partial interface IFavoritesRepository:IRepository<Favorites>
    {
       
    }    
}

    