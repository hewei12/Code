
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Designer 仓储
    /// </summary>        
    public partial interface IDesignerRepository:IRepository<Designer>
    {
       
    }    
}

    