
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// HouseArea 仓储
    /// </summary>        
    public partial interface IHouseAreaRepository:IRepository<HouseArea>
    {
       
    }    
}

    