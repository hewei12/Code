
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// DefinePage 仓储
    /// </summary>        
    public partial interface IDefinePageRepository:IRepository<DefinePage>
    {
       
    }    
}

    