
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Message 仓储
    /// </summary>        
    public partial interface IMessageRepository:IRepository<Message>
    {
       
    }    
}

    