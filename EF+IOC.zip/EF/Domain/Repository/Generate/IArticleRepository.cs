
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Article 仓储
    /// </summary>        
    public partial interface IArticleRepository:IRepository<Article>
    {
       
    }    
}

    