
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// GoodsInfo 仓储
    /// </summary>        
    public partial interface IGoodsInfoRepository:IRepository<GoodsInfo>
    {
       
    }    
}

    