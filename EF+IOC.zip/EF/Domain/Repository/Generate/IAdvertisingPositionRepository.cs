
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// AdvertisingPosition 仓储
    /// </summary>        
    public partial interface IAdvertisingPositionRepository:IRepository<AdvertisingPosition>
    {
       
    }    
}

    