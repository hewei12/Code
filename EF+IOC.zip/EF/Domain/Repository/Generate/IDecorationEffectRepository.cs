
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// DecorationEffect 仓储
    /// </summary>        
    public partial interface IDecorationEffectRepository:IRepository<DecorationEffect>
    {
       
    }    
}

    