
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// SupportContent 仓储
    /// </summary>        
    public partial interface ISupportContentRepository:IRepository<SupportContent>
    {
       
    }    
}

    