
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// TimeDiscount 仓储
    /// </summary>        
    public partial interface ITimeDiscountRepository:IRepository<TimeDiscount>
    {
       
    }    
}

    