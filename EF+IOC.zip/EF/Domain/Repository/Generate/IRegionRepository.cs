
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Region 仓储
    /// </summary>        
    public partial interface IRegionRepository:IRepository<Region>
    {
       
    }    
}

    