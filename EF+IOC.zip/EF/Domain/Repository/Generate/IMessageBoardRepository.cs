
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MessageBoard 仓储
    /// </summary>        
    public partial interface IMessageBoardRepository:IRepository<MessageBoard>
    {
       
    }    
}

    