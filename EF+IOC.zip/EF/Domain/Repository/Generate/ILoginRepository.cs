
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Login 仓储
    /// </summary>        
    public partial interface ILoginRepository:IRepository<Login>
    {
       
    }    
}

    