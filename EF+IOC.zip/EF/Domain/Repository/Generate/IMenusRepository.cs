
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Menus 仓储
    /// </summary>        
    public partial interface IMenusRepository:IRepository<Menus>
    {
       
    }    
}

    