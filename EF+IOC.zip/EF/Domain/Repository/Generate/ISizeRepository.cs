
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Size 仓储
    /// </summary>        
    public partial interface ISizeRepository:IRepository<Size>
    {
       
    }    
}

    