
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MallOrderPay 仓储
    /// </summary>        
    public partial interface IMallOrderPayRepository:IRepository<MallOrderPay>
    {
       
    }    
}

    