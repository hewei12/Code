
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Color 仓储
    /// </summary>        
    public partial interface IColorRepository:IRepository<Color>
    {
       
    }    
}

    