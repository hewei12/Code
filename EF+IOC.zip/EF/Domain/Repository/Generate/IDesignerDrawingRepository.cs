
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// DesignerDrawing 仓储
    /// </summary>        
    public partial interface IDesignerDrawingRepository:IRepository<DesignerDrawing>
    {
       
    }    
}

    