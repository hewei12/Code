
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MallOrder 仓储
    /// </summary>        
    public partial interface IMallOrderRepository:IRepository<MallOrder>
    {
       
    }    
}

    