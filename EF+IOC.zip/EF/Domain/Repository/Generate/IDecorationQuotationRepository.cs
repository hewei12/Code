
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// DecorationQuotation 仓储
    /// </summary>        
    public partial interface IDecorationQuotationRepository:IRepository<DecorationQuotation>
    {
       
    }    
}

    