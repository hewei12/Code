
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MerchantsEnter 仓储
    /// </summary>        
    public partial interface IMerchantsEnterRepository:IRepository<MerchantsEnter>
    {
       
    }    
}

    