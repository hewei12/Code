
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// BarCode 仓储
    /// </summary>        
    public partial interface IBarCodeRepository:IRepository<BarCode>
    {
       
    }    
}

    