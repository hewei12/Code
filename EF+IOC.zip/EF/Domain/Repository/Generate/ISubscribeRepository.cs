
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Subscribe 仓储
    /// </summary>        
    public partial interface ISubscribeRepository:IRepository<Subscribe>
    {
       
    }    
}

    