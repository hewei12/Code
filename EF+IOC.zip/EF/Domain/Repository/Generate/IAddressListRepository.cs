
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// AddressList 仓储
    /// </summary>        
    public partial interface IAddressListRepository:IRepository<AddressList>
    {
       
    }    
}

    