
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// HousePlace 仓储
    /// </summary>        
    public partial interface IHousePlaceRepository:IRepository<HousePlace>
    {
       
    }    
}

    