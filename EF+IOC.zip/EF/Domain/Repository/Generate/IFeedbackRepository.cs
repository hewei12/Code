
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Feedback 仓储
    /// </summary>        
    public partial interface IFeedbackRepository:IRepository<Feedback>
    {
       
    }    
}

    