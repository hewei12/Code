
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Role 仓储
    /// </summary>        
    public partial interface IRoleRepository:IRepository<Role>
    {
       
    }    
}

    