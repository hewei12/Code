
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// HouseSite 仓储
    /// </summary>        
    public partial interface IHouseSiteRepository:IRepository<HouseSite>
    {
       
    }    
}

    