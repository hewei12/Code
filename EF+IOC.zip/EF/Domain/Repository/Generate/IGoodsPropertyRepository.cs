
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// GoodsProperty 仓储
    /// </summary>        
    public partial interface IGoodsPropertyRepository:IRepository<GoodsProperty>
    {
       
    }    
}

    