
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// RoleMenus 仓储
    /// </summary>        
    public partial interface IRoleMenusRepository:IRepository<RoleMenus>
    {
       
    }    
}

    