
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MallOrderDeliveryFlag 仓储
    /// </summary>        
    public partial interface IMallOrderDeliveryFlagRepository:IRepository<MallOrderDeliveryFlag>
    {
       
    }    
}

    