
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// MallOrderItem 仓储
    /// </summary>        
    public partial interface IMallOrderItemRepository:IRepository<MallOrderItem>
    {
       
    }    
}

    