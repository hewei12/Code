
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Users 仓储
    /// </summary>        
    public partial interface IUsersRepository:IRepository<Users>
    {
       
    }    
}

    