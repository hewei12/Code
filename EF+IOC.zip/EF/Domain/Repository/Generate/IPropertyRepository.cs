
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Property 仓储
    /// </summary>        
    public partial interface IPropertyRepository:IRepository<Property>
    {
       
    }    
}

    