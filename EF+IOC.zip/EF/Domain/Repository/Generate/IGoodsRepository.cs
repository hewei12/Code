
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// Goods 仓储
    /// </summary>        
    public partial interface IGoodsRepository:IRepository<Goods>
    {
       
    }    
}

    