
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// UserOAuthMapping 仓储
    /// </summary>        
    public partial interface IUserOAuthMappingRepository:IRepository<UserOAuthMapping>
    {
       
    }    
}

    