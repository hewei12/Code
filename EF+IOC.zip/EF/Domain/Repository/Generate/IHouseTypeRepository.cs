
using EFModel;
namespace Domain.Repository
{
    /// <summary>
    /// HouseType 仓储
    /// </summary>        
    public partial interface IHouseTypeRepository:IRepository<HouseType>
    {
       
    }    
}

    