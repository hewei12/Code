﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Repository
{
    /// <summary>
    /// 仓储接口
    /// </summary>
    /// <typeparam name="T">类型参数</typeparam>
    public partial interface IRepository<T> where T : class
    {
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="entity">数据实体</param>
        /// <returns></returns>
        T Add(T entity);
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="entity">数据实体</param>
        /// <returns>添加后的数据实体</returns>
        bool AddOk(T entity);
        /// <summary>
        /// 查询记录数
        /// </summary>
        /// <param name="predicate">条件表达式</param>
        /// <returns></returns>
        int Count(Expression<Func<T, bool>> predicate);
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity">数据实体</param>
        /// <returns>是否成功</returns>
        T Update(T entity);
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity">数据实体</param>
        /// <returns>是否成功</returns>
        bool UpdateOK(T entity);
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="entity">数据实体</param>
        /// <returns>是否成功</returns>
        bool Delete(T entity);
        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="anyLambda">条件表达式</param>
        /// <returns></returns>
        bool Exist(Expression<Func<T, bool>> anyLambda);
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="whereLambda">查询表达式</param>
        /// <returns>查询实体</returns>
        T Find(Expression<Func<T, bool>> whereLambda);
        /// <summary>
        /// 查询数据列表
        /// </summary>
        /// <param name="whereLamdba">条件表达式</param>
        /// <returns></returns>
        IQueryable<T> FindList(Expression<Func<T, bool>> whereLamdba);
        /// <summary>
        /// 查询数据列表
        /// </summary>
        /// <typeparam name="O">排序</typeparam>
        /// <param name="whereLambda">查询表达式</param>
        /// <param name="isAsc">是否升序</param>
        /// <param name="orderLambda">排序表达式</param>
        /// <returns></returns>
        IQueryable<T> FindList<O>(Expression<Func<T, bool>> whereLambda, bool isAsc, Expression<Func<T, O>> orderLambda);
        /// <summary>
        /// 查询分页列表数据
        /// </summary>
        /// <typeparam name="O">排序</typeparam>
        /// <param name="page">页码</param>
        /// <param name="pageSize">条数</param>
        /// <param name="totalRecord">总记录数</param>
        /// <param name="whereLambda">条件表达式</param>
        /// <param name="isAsc">是否升序</param>
        /// <param name="orderLambda">排序表达式</param>
        /// <returns></returns>
        IQueryable<T> FindPageList<O>(int page, int pageSize, out int totalRecord, Expression<Func<T, bool>> whereLambda, bool isAsc, Expression<Func<T, O>> orderLambda);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters">可变数组</param>
        /// <returns></returns>
        // List<T> FindListBySql<T>(string sql, params object[] parameters);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        int ExcuteSql(string sql, params object[] parameters);
    }
}
