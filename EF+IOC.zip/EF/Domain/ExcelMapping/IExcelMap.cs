﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Npoi.Configs;

namespace Domain.ExcelMapping
{
    /// <summary>
    /// Excel
    /// </summary>
    public interface IExcelMap
    {
        void Init();
    }
    /// <summary>
    /// Excel泛型映射
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IExcelMap<T> : IExcelMap where T : class
    {
        void Init(FluentConfiguration<T> config);
    }
}
