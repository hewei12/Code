﻿using Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Npoi.Configs;

namespace Domain.ExcelMapping.Import
{
    public class ImportDeptMap : ExcelMapBase<Dept>, IExcelMap<Dept>
    {
        public override void Init(FluentConfiguration<Dept> config)
        {
            config.Property(x => x.Name, x => { x.SetTitle("部门").SetMaxLength(64); });
        }
    }
}
