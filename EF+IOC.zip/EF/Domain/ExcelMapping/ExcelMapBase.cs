﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Npoi;
using Wolf.Infrastructure.Npoi.Configs;

namespace Domain.ExcelMapping
{
    public abstract class ExcelMapBase<T> : IExcelMap<T> where T:class
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        public abstract void Init(FluentConfiguration<T> config);

        /// <summary>
        /// 
        /// </summary>
        public void Init()
        {
            Init(Excel.Setting.For<T>());
        }
    }
}
