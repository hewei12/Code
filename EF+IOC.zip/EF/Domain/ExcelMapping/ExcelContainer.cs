﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ExcelMapping
{
    /// <summary>
    /// 
    /// </summary>
    public class ExcelContainer
    {
        /// <summary>
        /// 
        /// </summary>
        public static void InitExcelMap()
        {
            var list = Bing.Utils.Helpers.Reflection.GetTypesByInterface<IExcelMap>(Assembly.GetAssembly(typeof(IExcelMap)));
            foreach (var item in list)
            {
                item.Init();
            }
        }
    }
}
