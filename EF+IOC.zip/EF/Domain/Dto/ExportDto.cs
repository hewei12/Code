﻿using Infrastructure.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Dto
{
    public class ExportDto
    {
        public ExportFileType Type { get; set; }

        public object Conditon { get; set; }

        public string Fields { get; set; }

        public Guid? MerchantId { get; set; }

        public Guid? UserId { get; set; }
    }
}
