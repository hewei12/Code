﻿//using EFModel;
using Domain.AutoMapper;
using Domain.Model;
using Domain.Repository;
using Infrastructure.UnityExtensions;
using Microsoft.Practices.Unity;
using Repository;
using Repository.Resp;
//using Repository.Resp.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Imp
{
    public class DeptService : IDeptService
    {
        //构造函数注入
        private IDeptRepository _deptRepository;
        ///// <summary>
        ///// 构造函数
        ///// </summary>
        ///// <param name="deptRepository"></param>
        public DeptService(IDeptRepository deptRepository)
        {
            _deptRepository = deptRepository;
        }

        //属性注入
        //[Dependency]
        //public DeptRepository _deptRepository
        //{
        //    get;
        //    set;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        [CachingCallHandler("100000")]
        public Dept GetDetail()
        {
            var a= this._deptRepository.Find(e => e.DeptID == new Guid("EEBB3742-278C-4378-A627-0541B811C44F"));
            var b = a.MapTo<EFModel.Dept, Dept>();
            return b;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dept"></param>
        [TransacionHandler]
        public void Save()
        {
            Dept dept = new Dept
            {
                DeptID = Guid.NewGuid(),
                Code = "",
                Creater = "xx",
                CreateTime = DateTime.Now,
                Editor = "xx",
                EditTime = DateTime.Now,
                Name = "yy",
                Status = 0
            };
            var a = dept.MapTo<Dept, EFModel.Dept>();
            this._deptRepository.Add(a);
            var b = this._deptRepository.Find(e => e.DeptID == new Guid("EEBB3742-278C-4378-A627-0541B811C44F"));
            //throw new Exception("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            b.Code = "xx";
            b.Creater = "xfd";
            this._deptRepository.Update(b);
        }
    }
}
