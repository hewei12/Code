﻿using Bing.Utils.Extensions;
using Domain.Dto;
using Domain.Model;
using Infrastructure.Enum;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Wolf.Infrastructure.CommonModel;
using Wolf.Infrastructure.Npoi.Exports;

namespace Service.Common
{
    public class ExportService:IExportService
    {
        public ExportService()
        { }

        protected ExportDto CurrentCondition { get; set; }

        protected string Title { get; set; }

        /// <summary>
        /// 获取导出任务
        /// </summary>
        /// <returns></returns>
        public IExportExcelProcess GetExportProcess(ExportDto dto)
        {
            this.CurrentCondition = dto;
            this.Title = dto.Type.Description();
            switch(dto.Type)
            {
                case ExportFileType.Barcode:
                    return GetExportExcelProcess<Dept>(ExportDept, dto.Conditon);
                default:
                    return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xx"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public ExportExcelProcess<T> GetExportExcelProcess<T>(GetExportDataEvent<T> xx,object condition) where T:class,new ()
        {
            GetExportDataEvent<T> func = new GetExportDataEvent<T>(xx);
            return new ExportExcelProcess<T>(func, condition);
        }

        #region ExportBarcode(导出国际码列表)

        /// <summary>
        /// 导出国际码列表
        /// </summary>
        /// <param name="condition">查询条件</param>
        /// <param name="queryCount">查询数量</param>
        /// <returns></returns>
        private IList<Dept> ExportDept(object condition, int queryCount)
        {
            var search = GetPageSearch<Dept>(condition, queryCount);
            //var result = this._barcodePoolService.GetPageList(search, CurrentCondition.MerchantId.SafeValue());
            //return result.Data;
            return null;
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="condition"></param>
        /// <param name="queryCount"></param>
        /// <returns></returns>
        public PagedSearch<T> GetPageSearch<T>(object condition,int queryCount) where T:class,new ()
        {
            var t = ((JObject)condition).ToObject<T>();
            PagedSearch<T> search = new PagedSearch<T>(1, queryCount, t);
            return search;
        }
    }
}
