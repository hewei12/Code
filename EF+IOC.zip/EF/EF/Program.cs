﻿using Domain.AutoMapper;
using Microsoft.Practices.Unity;
using Service;
using Service.Imp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF
{
    class Program
    {
        static void Main(string[] args)
        {
            InitMapper.Init();
            UnityConfig.RegisterComponents();
            
            var deptService=UnityConfig.Container.Resolve<IDeptService>();

            //for (int i = 0; i < 3; i++)
            //{
            //    var dept = deptService.GetDetail();
            //}

            deptService.Save();

            Console.WriteLine("OK");
            Console.ReadKey();
        }
    }
}
