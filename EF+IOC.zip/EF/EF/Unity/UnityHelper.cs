﻿using Domain.Repository;
using EFModel;
using Infrastructure.Cache;
using Infrastructure.UnityExtensions;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using Microsoft.Practices.Unity.InterceptionExtension;
using Repository;
using Repository.Resp;

using Service;
using Service.Imp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.Domain.Uow;

namespace EF
{
    public class UnityHelper
    {
        private static IUnityContainer _unityContainer;

        public static IUnityContainer GetUnityContainer()
        {
            if (_unityContainer == null)
                _unityContainer = BuildUnityContainer();
            return _unityContainer;
        }

        public static IUnityContainer BuildUnityContainer()
        {
            #region 配置文件
            //var container = new UnityContainer();
            //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            //fileMap.ExeConfigFilename = Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "CfgFiles\\Unity.Config.xml");
            //Configuration configuration = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            //UnityConfigurationSection section = (UnityConfigurationSection)configuration.GetSection(UnityConfigurationSection.SectionName);
            //section.Configure(container, "ruanmouContainer");
            //container.LoadConfiguration(section);
            //return container;
            #endregion

            #region 代码
            IUnityContainer container = new UnityContainer();
            container.RegisterType<DbContext, EFDbContext>();
            //container.RegisterType<IUnitOfWork, CustomUnitOfWork>(new InjectionConstructor("EFDbContext"));
            container.RegisterType<IUnitOfWork, CustomUnitOfWork>();
            container.RegisterType<IDeptRepository, DeptRepository>();
            container.RegisterType<ICacheService, CacheService>();


            //添加扩展
            container.AddNewExtension<Interception>().RegisterType<IDeptService, DeptService>();
            //通过ICallHandler扩展
            container.Configure<Interception>().SetInterceptorFor<IDeptService>(new InterfaceInterceptor());
            //通过IInterceptionBehavior扩展
            container.RegisterType<IDeptService, DeptService>(new InterceptionBehavior<ExceptionLogBehavior>());
            return container;
            #endregion 
        }
    }
}
