﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF
{
    public class UnityConfig
    {
        public static IUnityContainer container = null;
        public static IUnityContainer Container
        {
            get { return container; }
            set { container = value; }
        }

        public static void RegisterComponents()
        {
            container = UnityHelper.GetUnityContainer();
        }
    }
}
