﻿using Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// 仓储抽象基类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class RepositoryBase<T> : Repository<T>, IRepository<T> where T : class
    {
        /// <summary>
        /// 
        /// </summary>
        protected CustomUnitOfWork _customUnitOfWork { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="unitOfWork"></param>
        protected RepositoryBase(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _customUnitOfWork = (CustomUnitOfWork)unitOfWork;
        }
    }
}
