using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// AddressList 仓储
    /// </summary>        
    public partial class AddressListRepository:RepositoryBase<AddressList>,IAddressListRepository
    {
        /// <summary>
        /// 初始化一个<see cref="AddressListRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public AddressListRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    