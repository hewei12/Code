using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// DefinePage 仓储
    /// </summary>        
    public partial class DefinePageRepository:RepositoryBase<DefinePage>,IDefinePageRepository
    {
        /// <summary>
        /// 初始化一个<see cref="DefinePageRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public DefinePageRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    