using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// Dept 仓储
    /// </summary>        
    public partial class DeptRepository:RepositoryBase<Dept>,IDeptRepository
    {
        /// <summary>
        /// 初始化一个<see cref="DeptRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public DeptRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    