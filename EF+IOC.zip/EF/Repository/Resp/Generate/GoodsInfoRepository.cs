using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// GoodsInfo 仓储
    /// </summary>        
    public partial class GoodsInfoRepository:RepositoryBase<GoodsInfo>,IGoodsInfoRepository
    {
        /// <summary>
        /// 初始化一个<see cref="GoodsInfoRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public GoodsInfoRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    