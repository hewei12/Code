using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// Article 仓储
    /// </summary>        
    public partial class ArticleRepository:RepositoryBase<Article>,IArticleRepository
    {
        /// <summary>
        /// 初始化一个<see cref="ArticleRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public ArticleRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    