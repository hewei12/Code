using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// Menus 仓储
    /// </summary>        
    public partial class MenusRepository:RepositoryBase<Menus>,IMenusRepository
    {
        /// <summary>
        /// 初始化一个<see cref="MenusRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public MenusRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    