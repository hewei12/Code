using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// MallOrderItem 仓储
    /// </summary>        
    public partial class MallOrderItemRepository:RepositoryBase<MallOrderItem>,IMallOrderItemRepository
    {
        /// <summary>
        /// 初始化一个<see cref="MallOrderItemRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public MallOrderItemRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    