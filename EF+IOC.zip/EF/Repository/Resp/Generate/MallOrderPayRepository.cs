using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// MallOrderPay 仓储
    /// </summary>        
    public partial class MallOrderPayRepository:RepositoryBase<MallOrderPay>,IMallOrderPayRepository
    {
        /// <summary>
        /// 初始化一个<see cref="MallOrderPayRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public MallOrderPayRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    