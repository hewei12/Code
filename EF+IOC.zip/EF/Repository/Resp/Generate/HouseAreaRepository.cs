using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// HouseArea 仓储
    /// </summary>        
    public partial class HouseAreaRepository:RepositoryBase<HouseArea>,IHouseAreaRepository
    {
        /// <summary>
        /// 初始化一个<see cref="HouseAreaRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public HouseAreaRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    