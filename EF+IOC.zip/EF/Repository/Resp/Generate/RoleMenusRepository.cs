using System;
using EFModel;
using Domain.Repository;
using System.Data.Entity;
using Wolf.Infrastructure.Domain.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// RoleMenus 仓储
    /// </summary>        
    public partial class RoleMenusRepository:RepositoryBase<RoleMenus>,IRoleMenusRepository
    {
        /// <summary>
        /// 初始化一个<see cref="RoleMenusRepository"/>类型的实例
        /// </summary>
        /// <param name="unitOfWork">工作单元</param>
        public RoleMenusRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }    
}

    