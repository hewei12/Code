﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repository.Resp;
using Domain.Repository;
using Wolf.Infrastructure.Domain.Uow;
using EFModel;

namespace Repository.Resp
{
    /// <summary>
    /// 
    /// </summary>
    public partial class DeptRepository : RepositoryBase<Dept>, IDeptRepository
    {
    
    }
}
