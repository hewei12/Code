﻿using Domain.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolf.Infrastructure.EntityFramework.Uow;

namespace Repository.Resp
{
    public class CustomUnitOfWork : UnitOfWork, ICustomUnitOfWork
    {
        /// <summary>
        /// 
        /// </summary>
        static CustomUnitOfWork()
        {
            Database.SetInitializer<CustomUnitOfWork>(null);
        }
        /// <summary>
        /// 
        /// </summary>
        public CustomUnitOfWork():base()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionName"></param>
        //public CustomUnitOfWork(string connectionName) : base()
        //{
           
        //}
    }
}
