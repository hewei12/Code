﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Domain.Repository;
using Wolf.Infrastructure.Domain.Uow;
using Wolf.Infrastructure.EntityFramework.Uow;

namespace Repository.Resp
{
    /// <summary>
    /// 仓储
    /// </summary>
    /// <typeparam name="T">类型参数</typeparam>
    public partial class Repository<T> : IRepository<T> where T : class
    {
        protected UnitOfWork _unitOfWork;
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="context">上下文</param>
        public Repository(IUnitOfWork unitOfWork)
        {
            _unitOfWork = (UnitOfWork)unitOfWork;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity">实体</param>
        /// <returns></returns>
        public T Add(T entity)
        {
            _unitOfWork.Entry<T>(entity).State = EntityState.Added;
            _unitOfWork.Commit();
            return entity;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity">实体</param>
        /// <returns></returns>
        public  bool AddOk(T entity)
        {
            _unitOfWork.Entry<T>(entity).State = EntityState.Added;
            return _unitOfWork.SaveChanges() > 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="predicate">表达式</param>
        /// <returns></returns>
        public  int Count(Expression<Func<T, bool>> predicate)
        {
            return _unitOfWork.Set<T>().AsNoTracking().Count(predicate);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public  bool Delete(T entity)
        {
            _unitOfWork.Set<T>().Attach(entity);
            _unitOfWork.Entry<T>(entity).State = EntityState.Deleted;
            return _unitOfWork.SaveChanges() > 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public  int ExcuteSql(string sql, params object[] parameters)
        {
            return _unitOfWork.Database.ExecuteSqlCommand(sql, parameters);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="anyLambda"></param>
        /// <returns></returns>
        public bool Exist(Expression<Func<T, bool>> anyLambda)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="whereLambda"></param>
        /// <returns></returns>
        public T Find(Expression<Func<T, bool>> whereLambda)
        {
            return _unitOfWork.Set<T>().AsNoTracking().FirstOrDefault<T>(whereLambda);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="whereLamdba"></param>
        /// <returns></returns>
        public IQueryable<T> FindList(Expression<Func<T, bool>> whereLamdba)
        {
            return _unitOfWork.Set<T>().AsNoTracking().Where<T>(whereLamdba);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="O"></typeparam>
        /// <param name="whereLambda"></param>
        /// <param name="isAsc"></param>
        /// <param name="orderLambda"></param>
        /// <returns></returns>
        public IQueryable<T> FindList<O>(Expression<Func<T, bool>> whereLambda, bool isAsc, Expression<Func<T, O>> orderLambda)
        {
            var list = _unitOfWork.Set<T>().AsNoTracking().Where(whereLambda);
            if (isAsc)
                list = list.OrderBy<T, O>(orderLambda);
            else
                list = list.OrderByDescending<T, O>(orderLambda);
            return list;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T1"></typeparam>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        // public List<T> FindListBySql<T>(string sql, params object[] parameters)
        //{
        //  return _context.Database.SqlQuery<T>(sql, parameters).ToList();
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="O"></typeparam>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecord"></param>
        /// <param name="whereLambda"></param>
        /// <param name="isAsc"></param>
        /// <param name="orderLambda"></param>
        /// <returns></returns>
        public IQueryable<T> FindPageList<O>(int page, int pageSize, out int totalRecord, Expression<Func<T, bool>> whereLambda, bool isAsc, Expression<Func<T, O>> orderLambda)
        {
            var list = _unitOfWork.Set<T>().AsNoTracking().Where(whereLambda);
            totalRecord = list.Count();
            if (isAsc)
                list = list.OrderBy<T, O>(orderLambda).Skip<T>((page - 1) * pageSize).Take<T>(pageSize);
            else
                list = list.OrderByDescending<T, O>(orderLambda).Skip((page - 1) * pageSize).Take<T>(pageSize);
            return list;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public T Update(T entity)
        {
            _unitOfWork.Set<T>().Attach(entity);
            _unitOfWork.Entry<T>(entity).State = EntityState.Modified;
            _unitOfWork.Commit();
            return entity;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool UpdateOK(T entity)
        {
            _unitOfWork.Set<T>().Attach(entity);
            _unitOfWork.Entry<T>(entity).State = EntityState.Modified;
            return _unitOfWork.SaveChanges() > 0;
        }
    }
}
