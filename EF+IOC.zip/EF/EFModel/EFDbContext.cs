namespace EFModel
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class EFDbContext : DbContext
    {
        public EFDbContext()
            : base("name=EFDbContext")
        {
        }

        public virtual DbSet<AddressList> AddressList { get; set; }
        public virtual DbSet<AdvertisingPosition> AdvertisingPosition { get; set; }
        public virtual DbSet<Article> Article { get; set; }
        public virtual DbSet<BarCode> BarCode { get; set; }
        public virtual DbSet<BasStatisticsData> BasStatisticsData { get; set; }
        public virtual DbSet<Cart> Cart { get; set; }
        public virtual DbSet<Color> Color { get; set; }
        public virtual DbSet<DecorationEffect> DecorationEffect { get; set; }
        public virtual DbSet<DecorationQuotation> DecorationQuotation { get; set; }
        public virtual DbSet<DefinePage> DefinePage { get; set; }
        public virtual DbSet<Dept> Dept { get; set; }
        public virtual DbSet<Designer> Designer { get; set; }
        public virtual DbSet<DesignerDrawing> DesignerDrawing { get; set; }
        public virtual DbSet<Favorites> Favorites { get; set; }
        public virtual DbSet<Feedback> Feedback { get; set; }
        public virtual DbSet<FullReduce> FullReduce { get; set; }
        public virtual DbSet<FullReduceGoods> FullReduceGoods { get; set; }
        public virtual DbSet<Goods> Goods { get; set; }
        public virtual DbSet<GoodsInfo> GoodsInfo { get; set; }
        public virtual DbSet<GoodsProperty> GoodsProperty { get; set; }
        public virtual DbSet<HouseArea> HouseArea { get; set; }
        public virtual DbSet<HousePlace> HousePlace { get; set; }
        public virtual DbSet<HouseSite> HouseSite { get; set; }
        public virtual DbSet<HouseStyoe> HouseStyoe { get; set; }
        public virtual DbSet<HouseType> HouseType { get; set; }
        public virtual DbSet<Login> Login { get; set; }
        public virtual DbSet<LoginMenus> LoginMenus { get; set; }
        public virtual DbSet<MallOrder> MallOrder { get; set; }
        public virtual DbSet<MallOrderDeliveryFlag> MallOrderDeliveryFlag { get; set; }
        public virtual DbSet<MallOrderItem> MallOrderItem { get; set; }
        public virtual DbSet<MallOrderPay> MallOrderPay { get; set; }
        public virtual DbSet<Menus> Menus { get; set; }
        public virtual DbSet<Merchants> Merchants { get; set; }
        public virtual DbSet<MerchantsEnter> MerchantsEnter { get; set; }
        public virtual DbSet<Message> Message { get; set; }
        public virtual DbSet<MessageBoard> MessageBoard { get; set; }
        public virtual DbSet<Property> Property { get; set; }
        public virtual DbSet<Region> Region { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RoleMenus> RoleMenus { get; set; }
        public virtual DbSet<Size> Size { get; set; }
        public virtual DbSet<Subscribe> Subscribe { get; set; }
        public virtual DbSet<SupportContent> SupportContent { get; set; }
        public virtual DbSet<ThumbsUp> ThumbsUpID { get; set; }
        public virtual DbSet<TimeDiscount> TimeDiscount { get; set; }
        public virtual DbSet<TimeDiscountGoods> TimeDiscountGoods { get; set; }
        public virtual DbSet<UserOAuthMapping> UserOAuthMapping { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AddressList>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.LinkMan)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<AddressList>()
                .Property(e => e.ZipCode)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<AdvertisingPosition>()
                .Property(e => e.Url)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<Article>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.CustomBC)
                .IsUnicode(false);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.MarketPrice)
                .HasPrecision(12, 2);

            modelBuilder.Entity<BarCode>()
                .Property(e => e.SalePrice)
                .HasPrecision(12, 2);

            modelBuilder.Entity<BasStatisticsData>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Color>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Color>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Color>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Color>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Color>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationEffect>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationEffect>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationEffect>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationEffect>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationEffect>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationQuotation>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationQuotation>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationQuotation>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<DecorationQuotation>()
                .Property(e => e.Area)
                .HasPrecision(12, 4);

            modelBuilder.Entity<DecorationQuotation>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<DefinePage>()
                .Property(e => e.Url)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<Dept>()
                .Property(e => e.LongName)
                .IsUnicode(false);

            modelBuilder.Entity<Designer>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Designer>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Designer>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Designer>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Designer>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<DesignerDrawing>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<DesignerDrawing>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<DesignerDrawing>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<DesignerDrawing>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DesignerDrawing>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<Favorites>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Favorites>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Feedback>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Feedback>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Feedback>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Feedback>()
                .Property(e => e.Message)
                .IsUnicode(false);

            modelBuilder.Entity<Feedback>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.ReduceType)
                .HasPrecision(18, 0);

            modelBuilder.Entity<FullReduce>()
                .Property(e => e.ReduceMoney)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.CustomNo)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Brand)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.BasePrice)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Goods>()
                .Property(e => e.MarketPrice)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Goods>()
                .Property(e => e.SalePrice)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Goods>()
                .Property(e => e.InstallFee)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Unit)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Goods>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<GoodsInfo>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<GoodsProperty>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<GoodsProperty>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<GoodsProperty>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<GoodsProperty>()
                .Property(e => e.Data)
                .IsUnicode(false);

            modelBuilder.Entity<HouseArea>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<HouseArea>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<HouseArea>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<HouseArea>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<HousePlace>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<HousePlace>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<HousePlace>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<HousePlace>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<HouseSite>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<HouseSite>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<HouseSite>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<HouseSite>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<HouseStyoe>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<HouseStyoe>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<HouseStyoe>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<HouseStyoe>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<HouseType>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<HouseType>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<HouseType>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<HouseType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Login1)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.PassWord)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Sheet)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.LinkMan)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.ItemAmount)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.InstallFee)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.Discount)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.TotalAmount)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrder>()
                .Property(e => e.BuyerMemo)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderDeliveryFlag>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderDeliveryFlag>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderItem>()
                .Property(e => e.Price)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrderItem>()
                .Property(e => e.InstallFee)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrderItem>()
                .Property(e => e.DiscountContent)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderItem>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.Sheet)
                .IsUnicode(false);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.Amount)
                .HasPrecision(12, 2);

            modelBuilder.Entity<MallOrderPay>()
                .Property(e => e.PayID)
                .IsUnicode(false);

            modelBuilder.Entity<Menus>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Menus>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Menus>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Menus>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Merchants>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Merchants>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Merchants>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Merchants>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Merchants>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Brand)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Company)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<MerchantsEnter>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Message>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<Message>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Message>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MessageBoard>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<MessageBoard>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<MessageBoard>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MessageBoard>()
                .Property(e => e.Message)
                .IsUnicode(false);

            modelBuilder.Entity<Property>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Property>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Property>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Property>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Property>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<Region>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Region>()
                .Property(e => e.EName)
                .IsUnicode(false);

            modelBuilder.Entity<Region>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<Region>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Role>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Role>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Role>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Role>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Size>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Size>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Size>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Size>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Size>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<Subscribe>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Subscribe>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Subscribe>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Subscribe>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Subscribe>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<SupportContent>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<ThumbsUp>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<ThumbsUp>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<TimeDiscount>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<TimeDiscount>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<TimeDiscount>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<TimeDiscount>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<TimeDiscount>()
                .Property(e => e.DiscountData)
                .HasPrecision(12, 2);

            modelBuilder.Entity<UserOAuthMapping>()
                .Property(e => e.AppID)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Login)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.PassWord)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.WeChat)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.QQ)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Token)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Mobile)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Amount)
                .HasPrecision(12, 2);

            modelBuilder.Entity<Users>()
                .Property(e => e.Creater)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Editor)
                .IsUnicode(false);

            modelBuilder.Entity<Users>()
                .Property(e => e.Note)
                .IsUnicode(false);
        }
    }
}
