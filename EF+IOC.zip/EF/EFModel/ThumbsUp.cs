namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ThumbsUpID")]
    public partial class ThumbsUp
    {
        [Key]
        [Column("ThumbsUpID")]
        public Guid ThumbsUpID1 { get; set; }

        public Guid UserID { get; set; }

        public int ThumbsUpType { get; set; }

        public Guid ThumbsUpData { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
