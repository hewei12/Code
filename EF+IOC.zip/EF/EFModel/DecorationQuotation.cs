namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DecorationQuotation")]
    public partial class DecorationQuotation
    {
        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        public Guid DecorationQuotationID { get; set; }

        public decimal Area { get; set; }

        public Guid? State { get; set; }

        public Guid? City { get; set; }

        public Guid? District { get; set; }

        public int? RoomCount { get; set; }

        public int HallCount { get; set; }

        public int? ToiletCount { get; set; }

        [StringLength(32)]
        public string Mobile { get; set; }

        public int Flag { get; set; }
    }
}
