namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TimeDiscountGoods
    {
        public Guid TimeDiscountGoodsID { get; set; }

        public Guid TimeDiscountID { get; set; }

        public Guid GoodsID { get; set; }

        public int SalesQty { get; set; }

        public int Flag { get; set; }
    }
}
