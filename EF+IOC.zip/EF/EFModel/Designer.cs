namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Designer")]
    public partial class Designer
    {
        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        [Key]
        [Column("Designer")]
        public Guid Designer1 { get; set; }

        [StringLength(64)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        public int? RecommendedFlag { get; set; }
    }
}
