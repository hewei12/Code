namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("FullReduce")]
    public partial class FullReduce
    {
        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        public Guid FullReduceID { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        public decimal ReduceType { get; set; }

        public decimal ReduceMoney { get; set; }

        public int FreeDeliveryFlag { get; set; }

        public int GoodsFlag { get; set; }

        public DateTime BeginTime { get; set; }

        public DateTime EndTime { get; set; }
    }
}
