namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MallOrderItem")]
    public partial class MallOrderItem
    {
        public Guid MallOrderItemID { get; set; }

        public Guid? MallOrderID { get; set; }

        public int? Qty { get; set; }

        public decimal? Price { get; set; }

        public decimal? InstallFee { get; set; }

        public int? DiscountType { get; set; }

        [StringLength(255)]
        public string DiscountContent { get; set; }

        public int? RefundFlag { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
