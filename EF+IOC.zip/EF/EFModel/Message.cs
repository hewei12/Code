namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Message")]
    public partial class Message
    {
        public Guid MessageID { get; set; }

        public Guid UserID { get; set; }

        [StringLength(8000)]
        public string Content { get; set; }

        public int MessageType { get; set; }

        public int ReadFlag { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
