namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MallOrderDeliveryFlag")]
    public partial class MallOrderDeliveryFlag
    {
        public Guid MallOrderDeliveryFlagID { get; set; }

        public Guid MallOrderID { get; set; }

        public int DeliveryFlag { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(4000)]
        public string Note { get; set; }
    }
}
