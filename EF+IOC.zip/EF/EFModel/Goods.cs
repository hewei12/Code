namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Goods
    {
        public Guid GoodsID { get; set; }

        public Guid DeptID { get; set; }

        public Guid MerchantsID { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        [StringLength(32)]
        public string CustomNo { get; set; }

        [StringLength(255)]
        public string Title { get; set; }

        [StringLength(64)]
        public string Brand { get; set; }

        public int SaleQty { get; set; }

        public decimal? BasePrice { get; set; }

        public decimal? MarketPrice { get; set; }

        public decimal? SalePrice { get; set; }

        public decimal? InstallFee { get; set; }

        [StringLength(64)]
        public string Unit { get; set; }

        public int StockStatus { get; set; }

        public DateTime? SendTime { get; set; }

        public int? Status { get; set; }

        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime? CreateTime { get; set; }

        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime? EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
