namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MerchantsEnter")]
    public partial class MerchantsEnter
    {
        public Guid MerchantsEnterID { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        [StringLength(64)]
        public string Brand { get; set; }

        [StringLength(64)]
        public string Company { get; set; }

        public Guid? State { get; set; }

        public Guid? City { get; set; }

        public Guid? District { get; set; }

        [StringLength(32)]
        public string Mobile { get; set; }

        public int MerchantsType { get; set; }

        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
