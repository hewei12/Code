namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MallOrder")]
    public partial class MallOrder
    {
        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        public Guid MallOrderID { get; set; }

        public Guid? BarCodeID { get; set; }

        [StringLength(32)]
        public string Sheet { get; set; }

        public Guid? State { get; set; }

        public Guid? City { get; set; }

        public Guid? District { get; set; }

        [StringLength(255)]
        public string Address { get; set; }

        [StringLength(32)]
        public string LinkMan { get; set; }

        [StringLength(32)]
        public string Phone { get; set; }

        [StringLength(32)]
        public string Mobile { get; set; }

        public decimal? ItemAmount { get; set; }

        public decimal? InstallFee { get; set; }

        public decimal? Discount { get; set; }

        public decimal? TotalAmount { get; set; }

        public int? TotalQty { get; set; }

        [StringLength(4000)]
        public string BuyerMemo { get; set; }

        public int DeliveryFlag { get; set; }

        public int RefundFlag { get; set; }

        public int Flag { get; set; }

        public DateTime? PayTime { get; set; }

        public DateTime? SendTime { get; set; }

        public DateTime? ConfirmTime { get; set; }

        public Guid DiscountID { get; set; }
    }
}
