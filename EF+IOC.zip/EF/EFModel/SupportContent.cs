namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SupportContent")]
    public partial class SupportContent
    {
        public Guid SupportContentID { get; set; }

        public Guid? GoodsID { get; set; }

        [Column(TypeName = "text")]
        public string Content { get; set; }
    }
}
