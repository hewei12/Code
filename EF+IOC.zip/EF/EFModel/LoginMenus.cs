namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class LoginMenus
    {
        public Guid LoginMenusID { get; set; }

        public Guid? LoginID { get; set; }

        public Guid? MenusID { get; set; }
    }
}
