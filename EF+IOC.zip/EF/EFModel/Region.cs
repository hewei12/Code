namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Region")]
    public partial class Region
    {
        public Guid RegionID { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        [StringLength(255)]
        public string EName { get; set; }

        [StringLength(64)]
        public string Code { get; set; }

        public Guid? ParentID { get; set; }

        public int LevelID { get; set; }

        public int Status { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
