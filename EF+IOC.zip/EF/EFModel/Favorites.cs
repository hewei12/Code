namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Favorites
    {
        public Guid FavoritesID { get; set; }

        public Guid UserID { get; set; }

        public int FavoritesType { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        public Guid FavoritesData { get; set; }
    }
}
