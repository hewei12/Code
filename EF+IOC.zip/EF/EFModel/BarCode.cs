namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BarCode")]
    public partial class BarCode
    {
        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        public Guid BarCodeID { get; set; }

        public Guid GoodsID { get; set; }

        public Guid SizeID { get; set; }

        public Guid ColorID { get; set; }

        [Required]
        [StringLength(32)]
        public string CustomBC { get; set; }

        public int StockQty { get; set; }

        public decimal? MarketPrice { get; set; }

        public decimal? SalePrice { get; set; }
    }
}
