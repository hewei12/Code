namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("UserOAuthMapping")]
    public partial class UserOAuthMapping
    {
        [Key]
        [StringLength(80)]
        public string AppID { get; set; }

        public Guid UserID { get; set; }

        public int Status { get; set; }

        public int AuthType { get; set; }
    }
}
