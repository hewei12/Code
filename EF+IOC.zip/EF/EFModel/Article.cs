namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Article")]
    public partial class Article
    {
        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        [Key]
        [Column("Article")]
        public Guid Article1 { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        public int ClickCount { get; set; }

        public int FavoritesCount { get; set; }

        public int CommentCount { get; set; }

        public int ArticleType { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        [Column(TypeName = "text")]
        public string Content { get; set; }
    }
}
