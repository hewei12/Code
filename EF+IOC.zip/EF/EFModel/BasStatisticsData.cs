namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BasStatisticsData")]
    public partial class BasStatisticsData
    {
        public Guid BasStatisticsDataID { get; set; }

        public DateTime StatisticsDate { get; set; }

        public int? LoginCount { get; set; }

        public int? RegisterCount { get; set; }

        public int? OrderCount { get; set; }

        public decimal? OrderAmount { get; set; }

        [StringLength(255)]
        public string Note { get; set; }
    }
}
