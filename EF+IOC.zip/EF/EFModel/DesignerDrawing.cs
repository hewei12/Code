namespace EFModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DesignerDrawing")]
    public partial class DesignerDrawing
    {
        public int Status { get; set; }

        [Required]
        [StringLength(64)]
        public string Creater { get; set; }

        public DateTime CreateTime { get; set; }

        [Required]
        [StringLength(64)]
        public string Editor { get; set; }

        public DateTime EditTime { get; set; }

        [StringLength(255)]
        public string Note { get; set; }

        [Key]
        [Column(Order = 0)]
        public Guid DesignerDrawingID { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int DecorationType { get; set; }

        public Guid? Designer { get; set; }

        [Required]
        [StringLength(64)]
        public string Name { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        public int FavoritiesCount { get; set; }

        public int ReadCount { get; set; }

        public int? PictureCount { get; set; }
    }
}
